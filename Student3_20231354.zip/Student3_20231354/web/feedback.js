document.getElementById("feedbackForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    // Clear previous error messages
    const errorElements = document.querySelectorAll(".error");
    errorElements.forEach(element => element.textContent = "");

    // Validate required fields
    let isValid = true;

    // Check Full Name
    const name = document.getElementById("name").value.trim();
    if (name === "") {
        document.getElementById("nameError").textContent = "Full Name is required.";
        isValid = false;
    }

    // Check Email
    const email = document.getElementById("email").value.trim();
    if (email === "") {
        document.getElementById("emailError").textContent = "Email Address is required.";
        isValid = false;
    }

    // Check Telephone Number
    const phone = document.getElementById("phone").value.trim();
    if (phone === "") {
        document.getElementById("phoneError").textContent = "Telephone Number is required.";
        isValid = false;
    }

    // Check Address
    const address = document.getElementById("address").value.trim();
    if (address === "") {
        document.getElementById("addressError").textContent = "Address is required.";
        isValid = false;
    }

    // Check Gender
    const gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        document.getElementById("genderError").textContent = "Gender is required.";
        isValid = false;
    }

    // Check Age Range
    const age = document.getElementById("age").value;
    if (age === "") {
        document.getElementById("ageError").textContent = "Age Range is required.";
        isValid = false;
    }

    // Check Preferred Contact Method
    const contactMethod = document.getElementById("contact_method").value;
    if (contactMethod === "") {
        document.getElementById("contactMethodError").textContent = "Preferred Contact Method is required.";
        isValid = false;
    }

    // Check Comment or Message
    const comment = document.getElementById("comment_message").value.trim();
    if (comment === "") {
        document.getElementById("commentError").textContent = "Comment or Message is required.";
        isValid = false;
    }

    // Check Rating
    const rating = document.querySelector('input[name="rating"]:checked');
    if (!rating) {
        document.getElementById("ratingError").textContent = "Rating is required.";
        isValid = false;
    }

    // Check Recommendation
    const recommend = document.querySelector('input[name="recommend"]:checked');
    if (!recommend) {
        document.getElementById("recommendError").textContent = "Please indicate if you would recommend our services.";
        isValid = false;
    }

    // Check Feedback Type
    const feedbackType = document.getElementById("feedback_type").value;
    if (feedbackType === "") {
        document.getElementById("feedbackTypeError").textContent = "Feedback Type is required.";
        isValid = false;
    }

    // Check Select Date
    const date = document.getElementById("date").value.trim();
    if (date === "") {
        document.getElementById("dateError").textContent = "Select Date is required.";
        isValid = false;
    }

    // If all fields are valid, submit the form
    if (isValid) {
        alert("Form submitted successfully!");
        this.submit(); // Uncomment this line to actually submit the form
    }
});